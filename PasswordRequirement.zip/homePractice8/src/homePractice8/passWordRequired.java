/**
 * Bailey Vickery
 * 10/17/23
 * This program will create a class to make sure that a users password will 
 * meet certain criteria 
 */
package homePractice8;
import java.util.Scanner;
/**
 * 
 */
public class passWordRequired{
	//field declarations 
	private boolean length = true;
	private boolean upper = true;
	private boolean digit;
	private boolean special;
	private String password;
	
	
	
	
	//open scanner
	Scanner keyboard = new Scanner(System.in);
	
	
	//method to get users password
	public void passWord() {
		
		//ask user for password and get input
		System.out.print("Please enter your password(Must be 8 ");
		System.out.print("characters long, have 2 uppercase letters, ");
		System.out.println("and one digit)");
		System.out.println("Password: ");
		password = keyboard.nextLine();
	}
	
	
	
	//methods to make sure each criteria is meet
	//length requirement
	public boolean meetLength() {
		length = password.length() >= 8;
		return length;
	}
	//uppercase requirement
	public boolean meetUpper() {
		int uppercase = 0;
		for(int i =0; i < password.length(); i++) {
			char c = password.charAt(i);
			if (Character.isUpperCase(c)) {
				uppercase++;
			}
		}
		upper = uppercase >= 2;
		
		return upper;
	}
	//digit requirement
	public boolean meetDigit() {
		digit= false;
		for(int i =0; i < password.length(); i++) {
			char c= password.charAt(i);
			if (Character.isDigit(c)) {
				digit= true;
			}
		}
		
		return digit;
	}
	
	public boolean meetSpecial() {
		special = false;
		for(int i =0; i < password.length(); i++) {
			char c= password.charAt(i);
			if(c == '!' || c == '#' || c=='*' || c=='$') {
				special = true;
			}
			 
		}
		return special;
	}
	
	//method to test all requirements
	public void passwordRequirements() {
		boolean all = false;
		do {
			if(!meetLength()) {
				System.out.println("Length requirement not meet.");
				all = false;
				passWord();
			}
			else if(!meetUpper()) {
				System.out.println("Uppercase requirement not meet.");
				all = false;
				passWord();
			}
			else if(!meetDigit()) {
				System.out.println("Digit requirement not meet.");
				all = false;
				passWord();
			}
			else if(!meetSpecial()) {
				System.out.println("Special character requirement not meet.");
				all = false;
				passWord();
			}
			else {
				System.out.println("Good password!");
				all=true;
			}
		}while(!all);
	}
	
	
}
