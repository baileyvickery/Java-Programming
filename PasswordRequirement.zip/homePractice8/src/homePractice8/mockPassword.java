/**
 * Bailey Vickery
 * 10/17/23
 * This program will mock a user inputting a password and 
 * uses the passWordRequired class to make sure it meets criteria
 */
package homePractice8;

/**
 * 
 */
public class mockPassword {

	
	public static void main(String[] args) {
		passWordRequired user = new passWordRequired();
		
		//gets user password
		user.passWord();
		
		//tests users password
		user.passwordRequirements();
		
		
	}

}
