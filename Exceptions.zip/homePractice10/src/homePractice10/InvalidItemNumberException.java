//Bailey Vickery 10/30/23
//This is an exception for invalid item numbers
package homePractice10;

public class InvalidItemNumberException extends Exception {

	public InvalidItemNumberException() {
		super("Invalid item number");
	}
	
	public InvalidItemNumberException(int number) {
		super("Invalid item number given " + number);
	}
}
	
