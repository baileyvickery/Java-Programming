//Bailey Vickery 10/30/23
//This is an exception for invalid quantities 
package homePractice10;

public class InvalidQuantityException extends Exception{
	
	public InvalidQuantityException() {
		super("Invalid quantity number");
	}
	
	public InvalidQuantityException(int number) {
		super("Invalid quantity number " + number);
	}
}
