//This program uses the orders class to demonstrate
//how it works
package homePractice10;

import java.util.Scanner;

public class DemoClass {
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		
		//create object 
		Orders newOrder = new Orders();
		
		//get users item number 
		System.out.print("Please enter your item number: ");
		int n = keyboard.nextInt();
		
		//get users quantity
		System.out.println("Please enter the quantity you are ordering: ");
		int q = keyboard.nextInt();
		
		//validate item number 
		try {
			newOrder.setItemNumber(n);
			newOrder.setQuantity(q);
		}
		catch(InvalidItemNumberException e){
			System.out.println("Error - " + e.getMessage());
		}
		catch(InvalidQuantityException e) {
			System.out.println("Error -" + e.getMessage());
		}
	
		
		
		//get users price and output order details
		System.out.print("Item Number: ");
		System.out.println(newOrder.getItemNumber());
		
		System.out.print("Quantity ordered: ");
		System.out.println(newOrder.getQuantity());
		
		System.out.print("Total: $");
		System.out.println(newOrder.getPrice(n, q));
		
		
	
		keyboard.close();
		
	}
}
