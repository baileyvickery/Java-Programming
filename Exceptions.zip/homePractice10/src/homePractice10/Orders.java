//Bailey Vickery 10/30/23
//This program is a class that uses two exceptions
//To validate item numbers and quantities
package homePractice10;

public class Orders {
	//field declarations
	int itemNumber;
	double price;
	int quantity;
	int[] validItem = {111, 222, 333, 444};
	boolean valid = false;
	
	//contstructors
	public Orders() {
		itemNumber = 0;
		price = 0.0;
		quantity = 0;
	}
	public Orders (int n, int q) throws InvalidItemNumberException, InvalidQuantityException {
		
		//check array of current in stock items 
		for(int i = 0; i < 4; i++) {
			if(n == validItem[i]) {
				valid = true;
				break;
			}
				
		}
		
		
		if (n < 0 || n > 9999 ) {
			throw new InvalidItemNumberException(n);
		}
		else if(valid == false)
			throw new InvalidItemNumberException(n);
		else
			itemNumber=n;

		
		//check if quantity is valid
		if(q <  1 || q > 12)
			throw new InvalidQuantityException(q);
		else
			quantity = q;
		
	}
	
	//get methods
	public int getItemNumber() {
		return itemNumber;
	}
	public double getPrice(int n, int q) {
		//get price depending on the item number
		if (n == 111)
			price = 0.89;
		else if(n == 222)
			price = 1.47;
		else if(n == 333)
			price = 2.43;
		else if(n == 444)
			price = 5.99;
		
		return price * q;
	}
	public int getQuantity() {
		return quantity;
	}

	//set methods
	public void setItemNumber(int n) throws InvalidItemNumberException{
		
		
		if (n < 0 || n > 9999 ) {
			throw new InvalidItemNumberException(n);
		}
		
		//reads through current stock and compares
		for(int i = 0; i < 4; i++) {
			if(n == validItem[i]) {
				valid = true;
				break;
			}
		}
		

		if(!valid)
			throw new InvalidItemNumberException(n);
		else
			itemNumber = n;

	}
	

	
	public void setQuantity(int q) throws InvalidQuantityException{
		if(q <  1 || q > 12)
			throw new InvalidQuantityException(q);
		else
			quantity = q;
	}
	
	
}


