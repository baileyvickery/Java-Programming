/**
 * 
 */
package realtor;

/**
 * Bailey Vickery
 * 11/22/23
 * This class stores the data about a new customer for the realtor
 * project
 */
public class person {

	//variables 
	private String fName;
	private String lName;
	private String phone;
	
	
	
	//constructor
	public  person(String first, String last, String phone2) {
		fName = first;
		lName = last;
		phone = phone2;
		
	}
	
	//no arg constructor
	public person() {
		fName = "";
		lName = "";
		phone = "";
	}
	
	//get methods 
	public String getFName() {
		return fName;
	}
	public String getLName() {
		return lName;
	}
	public String getPhone() {
		return phone;
	}
	//set methods 
	public void setFName(String first) {
		fName = first;
	}
	public void setLName(String last) {
		lName = last;
	}
	public void setPhone(String number) {
		phone = number;
	}
	
	
}
