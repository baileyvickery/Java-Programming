/**
 * 
 */
package realtor;



/**
 * Bailey Vickery
 * 11/22/23
 * This class creates a Customer object 
 */
public class Customer extends person{
	private String rentBuy;
	
	
	//constructor
	public Customer(String first, String last, String num, String choice) {
		super(first, last, num);
		
		rentBuy=choice;
	}
	//get and sets
	
	public void setRentBuy(String choice) {
		rentBuy = choice;
	}
	public String getRentBuy() {
		return rentBuy;
	}
	
	
	public Customer() {
		super();
		
		//possibly add customer number, or rent or buy. Needs something more to extend super
	}

}
