/*
 * Bailey Vickery
 * 12/12/23
 * This class uses a file exception and a customer object to a GUI to help people find a trust
 * worthy realtor
 */
package realtor;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTextField;

public class GUI extends JFrame implements ActionListener{
	//add layout
		FlowLayout flow = new FlowLayout();
		
		//give customer overview of what this program does
		JLabel overview = new JLabel ("Hello! Are you having trouble finding a trustworhty realtor? ");
		JLabel overview2 = new JLabel("No worries, this program will help pair you with a realtor that ");
		JLabel overview3 = new JLabel("exceds your expectations!");
		
		//add text boxes and labels to get users name and number
		JLabel firstLabel = new JLabel("Please enter your first name: ");
		JTextField first = new JTextField(15);
		JLabel lastLabel = new JLabel("Please enter your last name: ");
		JTextField last = new JTextField(15);
		JLabel phoneLabel = new JLabel("Please enter your phone number(xxxxxxxxxx):");
		JTextField phone = new JTextField(10);
		
		
		//ask user if they are renting or buying
		JLabel choice = new JLabel("Awesome, now are you looking to buy or rent? ");
		JCheckBox rent = new JCheckBox("Rent", false);
		JCheckBox buy = new JCheckBox("Buy", false);
		
		//create realtor labels
		JLabel realtors = new JLabel("Here our some of our realtors: ");
		JList realtorsOutput = new JList();
		
		//add label to inform them the realtor list also got wrote to a file
		JLabel file = new JLabel("We also created a file for you with the realtors names and phone numbers listed.");
		
		
		//add button
		JButton submit = new JButton("Submit");
		
		
		public GUI() {
			super("Realtor Finder");
			
			
			//add layout and close operator
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setLayout(flow);
			getContentPane().setBackground(new java.awt.Color(255, 250, 240));
			
			//add labels, text boxes and check boxes
			add(overview);
			add(overview2);
			add(overview3);
			add(firstLabel);
			add(first);
			add(lastLabel);
			add(last);
			add(phoneLabel);
			add(phone);
			add(choice);
			add(rent);
			add(buy);
			add(submit);
			realtors.setVisible(false);
			add(realtors);
			add(realtorsOutput);
			file.setVisible(false);
			add(file);
			submit.addActionListener(this);
			
			
		}
		
		public static void main(String[] args) {
			//create frame and size
			GUI IFrame = new GUI();
			IFrame.setSize(800,300);
			IFrame.setVisible(true);
			
		}
		
		
		@Override
		public void actionPerformed(ActionEvent e) {
			//realtors arrays
			final String[] rentRealtors = {"Logan Scott", "Kelsea Maria", "Wilson Fletcher", "April Rain"};
			final String[] buyRealtors = {"Helen Davis", "Rob William", "Jenna Fisher", "Nathan David"};
			final String[] rentRealNums = {"517-234-2341", "456-234-7890", "345-123-6789", "567-789-8989"};
			final String[] buyRealNums = {"123-123-1234", "546-345-7865", "517-345-2341", "269-565-3467"};
			
			//try and catch to extract data from text fields
			Customer cust1 = new Customer();
			try {
				String fName = first.getText();
				cust1.setFName(fName);
				String lName = last.getText();
				cust1.setLName(lName);
				String num = phone.getText();
				cust1.setPhone(num);
			} catch (Exception except) {
				except.printStackTrace();
			}
			
			//try and catch to display options depending on choice
			try {
				//if statements for user choice: rent or buy
				if(rent.isSelected()) {
					
					//set customer rent Buy choice
					String rB = rent.getText();
					cust1.setRentBuy(rB);
				
					//output realtors to output file
				
					PrintWriter outputFile = new PrintWriter("RealtorsData.txt");
					for(int i = 0; i < rentRealtors.length; i++) {
						outputFile.println(rentRealtors[i]);
						outputFile.println(rentRealNums[i]);
					}
					
					outputFile.close();

				
					//output realtors to GUI
					realtors.setVisible(true);
					realtorsOutput.setListData(rentRealtors);
					realtorsOutput.setVisible(true);
					file.setVisible(true);
				
				}
				if(buy.isSelected()) {
					
					//set customer rent Buy choice
					String rB = buy.getText();
					cust1.setRentBuy(rB);
				
				
					//output realtors to output file
					PrintWriter outputFile = new PrintWriter("RealtorsData.txt");
					for(int i = 0; i < buyRealtors.length; i++) {
						outputFile.println(buyRealtors[i]);
						outputFile.println(buyRealNums[i]);
					}
					outputFile.close();
				
					//output realtors to GUI
					realtors.setVisible(true);
					realtorsOutput.setListData(buyRealtors);
					realtorsOutput.setVisible(true);
					file.setVisible(true);
				
				}	
			 } catch (FileNotFoundException ex) {
		            // Handle the custom exception
		            System.out.println("File not found");
		        }
			
		
		}
}
