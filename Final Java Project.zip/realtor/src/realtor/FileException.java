/*
 * Bailey Vickery
 * 12/8/23
 * This class handles the exception if a file cannot be opened or created
 */
package realtor;

public class FileException extends Exception {
	public FileException() {
		super("File not found");
	}
	
	public FileException(Throwable cause) {
		super("File not found", cause);
	}
}
