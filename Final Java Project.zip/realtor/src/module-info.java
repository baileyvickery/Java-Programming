/**
 * 
 */
/**
 * 
 */
module realtor {
	requires java.desktop;
}