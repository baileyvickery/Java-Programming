/**
 * 
 */
/**
 * 
 */
module swing {
	requires java.desktop;
}