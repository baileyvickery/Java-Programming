/*
 * Bailey Vickery 11/7/23 
 * This program uses GUI to get a users bill
 * and then will calculate a 20% tip and 
 * 6% sales tax
 */
package swing;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


public class GUI extends JFrame implements ActionListener{
	
	//create labels and text fields and button
	JLabel label = new JLabel("Please add your bill's total:");
	JTextField billField = new JTextField(6);
	JLabel tipLabel = new JLabel("20% tip: $");
	JTextField tipField = new JTextField(6);
	JLabel taxLabel = new JLabel("6% sales tax: $");
	JTextField taxField = new JTextField(6);
	JLabel totalLabel = new JLabel("Total Bill:$");
	JTextField totalField = new JTextField(6);
	JButton button = new JButton("Calculate");
	
	
	public GUI() {
		super("Bill Calculator");
		setSize(500, 150);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//add layout and change color
		setLayout(new FlowLayout());
		getContentPane().setBackground(new java.awt.Color(255, 245, 238));
		//add labels, text fields, and button
		add(label);
		add(billField);
		add(tipLabel);
		add(tipField);
		add(taxLabel);
		add(taxField);
		add(totalLabel);
		add(totalField);
		add(button);
		button.addActionListener(this);
		
		
		
	}


	public static void main(String[] args) {
		
		GUI frame = new GUI();
		frame.setVisible(true); //makes frame visible
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		try {
			double bill = Double.parseDouble(billField.getText());
			double tip = bill * .20;
			double tax = bill * .06;
			double total = bill + tip + tax;
			DecimalFormat df = new DecimalFormat("#.00");
			tipField.setText(String.valueOf(df.format(tip)));
			taxField.setText(String.valueOf(df.format(tax)));
			totalField.setText(String.valueOf(df.format(total)));
		}
		catch(NumberFormatException n)
		{
			JOptionPane.showMessageDialog(null, "Error: you must enter a number for bill total");
		}
		
	}

}



