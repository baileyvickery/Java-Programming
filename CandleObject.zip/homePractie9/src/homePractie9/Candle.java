package homePractie9;
/*
 * Bailey Vickery
 * 10/24/23
 * The candle class stores data about the price of a 
 * candle
 */

public class Candle {
	//variables
	protected String color;
	protected int height;
	protected double price;
	
	//constructor 
	public Candle(String col, int h) {
		color = col;
		height=h;
		price = h * 2.00;
	}
	//no arg constructor
	public Candle() {
		color = "";
		height=0;
		price = 0;
	}
		
	//get methods
	public String getColor() {
		return color;
	}
	public int getHeight() {
		return height;
	}
	public double getPrice() {
		return price;
	}
	
	//set methods
	public void setColor(String col) {
		color = col;
	}
	public void setHeight(int h) {
		height=h;
		price = h * 2.00;  //determines price
	}
	

	
}
