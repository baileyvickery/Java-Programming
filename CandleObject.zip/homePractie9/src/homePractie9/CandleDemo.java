package homePractie9;

import java.util.Scanner;

/*
 * Bailey Vickery
 * 10//24/23
 * This class uses the Candle class and the ScentedCadle
 * class to demonstrate how it works  with a user
 */


public class CandleDemo {

	public static void main(String[] args) {
		//scent array
		String[] scentOptions = new String[] {"lavender", "peppermint", "cedarwood", "gardenia"};
		
		//variables
		String col;
		int h;
		String scent;
		
		
		
		// create objects
		Candle candle = new Candle();
		ScentedCandle scented = new ScentedCandle();
		
		//prompt users for regular candle
		System.out.println("Hello! First let's create an unscented candle");
		System.out.println("What color would you like your candle to be? ");
		
		//open scanner
		Scanner keyboard = new Scanner(System.in);
		
		//read in customers color
		col = keyboard.next();
		candle.setColor(col);
		
		//get candle height
		System.out.println("Please enter how tall your candle is(Please exclude the units): ");
		h = keyboard.nextInt();
		candle.setHeight(h);
		
		System.out.printf("The price for your " + col + " unscented candle is: $%.2f\n", candle.price);

		//prompt user for scented candle
		System.out.println("Awesome! Now let's make a scented candle!");
		
		//get color
		System.out.println("What color would you like your candle to be? ");
		col = keyboard.next();
		scented.setColor(col);
		
		//get height
		System.out.println("Please enter how tall your candle is(Please exclude the units): ");
		h = keyboard.nextInt();
		scented.setHeight(h);
		
		//get scent
		System.out.print("Please choose one of our scent choices ");
		for(int i = 0; i < scentOptions.length; i++) {
			System.out.print(scentOptions[i] + " ");
		}
		scent = keyboard.next();
		
		System.out.printf("Beautiful! The cost for your " + col + " " + scent + " scented candle is: $%.2f\n", scented.price);

	}

}
