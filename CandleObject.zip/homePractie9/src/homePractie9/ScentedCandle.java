package homePractie9;
/*
 * Bailey Vickery
 * 10/24/23
 * The ScentedCandle class stores data about a candle that 
 * is scented.
 */

public class ScentedCandle extends Candle{
	//variables
	private String scent;
	
	//constructor
	public ScentedCandle(String col, int h) {
		super(col, h);
		price = 0;
	}
	//no arg constructor
	public ScentedCandle() {
		super();
		price = 0;
	}
	
	
	//get method
	public String getScent() {
		return scent;
	}
	
	//set method
	public void setScent(String s) {
		scent = s;
	}
	
	//override parent's method
	public void setHeight(int h) {
		height=h;
		price = h * 3.00;  //determines price
	}
	
}
