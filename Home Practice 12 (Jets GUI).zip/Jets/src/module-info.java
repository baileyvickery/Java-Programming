/**
 * 
 */
/**
 * 
 */
module Jets {
	requires java.desktop;
}