/**
 * 
 */
package jet;


import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 * Bailey Vickery 11/14/23
 * This program creates a GUI that displays the 
 * services that Jets provides and allows 
 * the user to choose which ones they want and 
 * then displays the total
 */
public class JJets extends JFrame implements ActionListener{

	//add layout
	FlowLayout flow = new FlowLayout();
	
	//add check boxes for the options
	JCheckBox oil = new JCheckBox("Oil Change", false);
	JCheckBox lube = new JCheckBox("Lube Job", false);
	JCheckBox radiator = new JCheckBox("Radiator Flush", false);
	JCheckBox trans = new JCheckBox("Transmission Flush", false);
	JCheckBox inspect = new JCheckBox("Inspectior", false);
	JCheckBox muffler = new JCheckBox("Muffler Replacement", false);
	JCheckBox tire = new JCheckBox("Tire Rotaion", false);
	JLabel laborLabel = new JLabel("Total hours of labor(Labor is $60/hour): ");
	JTextField laborField = new JTextField(6);
	
	//create label and text field
	JLabel costLabel = new JLabel("Total Cost: ");
	JTextField cost = new JTextField(10);
	//create button
	JButton select = new JButton("Submit");
	
	
	public JJets() {
		super("Services Selector");
		
		//add layout and close operator 
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(flow);
		getContentPane().setBackground(new java.awt.Color(255, 250, 240));
		
		//add check boxes
		add(oil);
		add(lube);
		add(radiator);
		add(trans);
		add(inspect);
		add(muffler);
		add(tire);
		add(laborLabel);
		add(laborField);
		
		//add total fields
		cost.setEditable(false);
		cost.setText("$0.00");
		add(costLabel);
		add(cost);
		//button submit
		add(select);
		select.addActionListener(this);
		
		
	}
	
	public static void main(String[] args) {
		//create frame and size
		JJets IFrame = new JJets();
		IFrame.setSize(400, 200);
		IFrame.setVisible(true);
		
		
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		//price variables 
		final int OILPRICE = 35;
		final int LUBEPRICE	 = 25;
		final int RADIATORPRICE = 50;
		final int TRANSPRICE = 120;
		final int INSPECTPRICE = 35;
		final int MUFFPRICE = 200;
		final int TIREPRICE = 20;
		int total = 0;
		int hours = Integer.parseInt(laborField.getText());
		
		//charge labor for 60$ and hour
		hours = hours * 60;
		
		//if statements to add prices to total
		if(oil.isSelected()) {
			total += OILPRICE;
			total += hours;
		}
		if(lube.isSelected()) {
			total += LUBEPRICE;
			total += hours;
		}
		if(radiator.isSelected()) {
			total += RADIATORPRICE;
			total += hours;
		}
		if(trans.isSelected()) {
			total += TRANSPRICE;
			total += hours;
		}
		if(inspect.isSelected()) {
			total += INSPECTPRICE;
			total += hours;
		}
		if(muffler.isSelected()) {
			total += MUFFPRICE;
			total += hours;
		}
		if(tire.isSelected()) {
			total += TIREPRICE;
			total += hours;
		}
		
		//output text
		cost.setText("$" + String.valueOf(total));
		
	}

}

